package src.db;

public class DBConstants {
	public static final String objectSequencer = "objectSequencer";
	public static final String typeKeys = "TYPEKEYS";
	public static final String typeKey = "TYPEKEY";
}
