/**--- Generated at Fri Nov 24 20:30:03 CET 2023 
 * --- No Change Allowed!  
 */
package generated.kinoService.proxies;
import src.idManagement.Identifiable;
import src.db.executer.PersistenceException;
import generated.kinoService.Parquet;
import java.util.Optional;
public interface IParquet extends ICategorie{
   public Parquet getTheObject();
   public Integer getId();
}
