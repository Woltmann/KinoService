package src.idManagement;

public interface Identifiable {
	public Integer getId();
}
